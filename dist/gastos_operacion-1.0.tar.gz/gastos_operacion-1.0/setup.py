from setuptools import setup

setup(
    name='gastos_operacion',
    version=1.0,
    description='Gastos de Operacion',
    author='Héctor Fernando Arredondo Sánchez',
    author_email='hector18fernando96@gmail.com',
    url='http://www.utng.edu.mx',
    py_modules=['gastos_operacion'],
)
